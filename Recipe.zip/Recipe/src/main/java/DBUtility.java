import java.sql.*;

public class DBUtility {
    private static final String url = "jdbc:mysql://localhost:3306/recipedb";
    private static final String user = "root";
    private static final String password = "Hunara98.";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public static ResultSet getIngredients(String dishName) throws SQLException {
        String query = "SELECT ingredient, percentage FROM Ingredients WHERE dish_name = ?";
        Connection connection = getConnection();
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, dishName);
        return statement.executeQuery();
    }
}