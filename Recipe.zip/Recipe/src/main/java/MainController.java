import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MainController {
    @FXML
    private PieChart mainPieChart;

    @FXML
    private void initialize() {
        // Initialize your controller, if needed
    }

    @FXML
    private void loadTacosChart(ActionEvent event) {
        loadChart("Tacos");
    }

    @FXML
    private void loadQuesadillaChart(ActionEvent event) {
        loadChart("Quesadilla");
    }

    @FXML
    private void loadGuacamoleChart(ActionEvent event) {
        loadChart("Guacamole");
    }

    @FXML
    private void loadTamalesChart(ActionEvent event) {
        loadChart("Tamales");
    }

    @FXML
    private void loadChilesEnNogadaChart(ActionEvent event) {
        loadChart("Chiles en Nogada");
    }

    private void loadChart(String dishName) {
        try {
            ResultSet resultSet = DBUtility.getIngredients(dishName);
            ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
            while (resultSet.next()) {
                String ingredient = resultSet.getString("ingredient");
                double percentage = resultSet.getDouble("percentage");
                String label = String.format("%s %.1f%%", ingredient, percentage); // Format label with percentage
                pieChartData.add(new PieChart.Data(label, percentage));
            }
            mainPieChart.setData(pieChartData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


